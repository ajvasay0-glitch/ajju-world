---
name: Optional AI providers
description: Product rule for optional AI integrations in Ajju World.
---

Ajju World must remain fully usable without AI provider configuration. AI features should stay disabled until a provider is explicitly configured and the user opts in. Keep provider credentials server-side and disclose external prompt handling and possible provider costs.

**Why:** The product requirement explicitly says image creation must be optional and must not make the rest of Ajju World depend on AI.

**How to apply:** Preserve this constraint when changing provider routes, UI states, or configuration.

import { StaticPage } from '@/pages/Pages';
export {
  Home, SearchPage, VideoPage, ShoppingPage, EducationPage, JobsPage, EarningPage,
  NewsPage, AIImagePage, AssistantPage, NotFound,
} from '@/pages/Pages';
export function AboutPage() { return <StaticPage kind="about" />; }
export function ContactPage() { return <StaticPage kind="contact" />; }
export function PrivacyPage() { return <StaticPage kind="privacy" />; }
export function TermsPage() { return <StaticPage kind="terms" />; }

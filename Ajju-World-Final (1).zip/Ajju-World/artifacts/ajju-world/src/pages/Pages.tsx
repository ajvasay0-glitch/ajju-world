import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { Link } from 'wouter';
import {
  ArrowRight, ArrowUpRight, BookOpen, BriefcaseBusiness, Compass, GraduationCap, Image,
  Newspaper, Search, ShoppingBag, Sparkles, Video, WalletCards, ShieldAlert, Download,
} from 'lucide-react';
import { languageNames, locales, useI18n, type TranslationKey } from '@/lib/i18n';
import { getAIImageCopy } from '@/lib/ai-image-copy';

type Resource = { name: string; href: string; description?: TranslationKey; requiresQuery?: boolean };
const categories: { href: string; title: TranslationKey; description: TranslationKey; icon: typeof Search; style: string }[] = [
  { href: '/search', title: 'categorySearch', description: 'categorySearchDesc', icon: Search, style: 'tool-search' },
  { href: '/video', title: 'categoryVideo', description: 'categoryVideoDesc', icon: Video, style: 'tool-video' },
  { href: '/shopping', title: 'categoryShopping', description: 'categoryShoppingDesc', icon: ShoppingBag, style: 'tool-shopping' },
  { href: '/education', title: 'categoryEducation', description: 'categoryEducationDesc', icon: GraduationCap, style: 'tool-education' },
  { href: '/jobs', title: 'categoryJobs', description: 'categoryJobsDesc', icon: BriefcaseBusiness, style: 'tool-jobs' },
  { href: '/earning', title: 'categoryEarning', description: 'categoryEarningDesc', icon: WalletCards, style: 'tool-earning' },
  { href: '/news', title: 'categoryNews', description: 'categoryNewsDesc', icon: Newspaper, style: 'tool-news' },
  { href: '/ai-image', title: 'categoryAIImage', description: 'categoryAIImageDesc', icon: Image, style: 'tool-ai' },
  { href: '/assistant', title: 'categoryAssistant', description: 'categoryAssistantDesc', icon: Sparkles, style: 'tool-ai' },
];
function outbound(url: string) { window.open(url, '_blank', 'noopener,noreferrer'); }
function searchForm(event: FormEvent<HTMLFormElement>, raw: string, makeUrl: (q: string) => string, invalid: string) {
  event.preventDefault();
  const q = raw.trim();
  if (!q) { window.alert(invalid); return false; }
  outbound(makeUrl(encodeURIComponent(q)));
  return true;
}

export function Header() {
  const { t, locale, setLocale } = useI18n();
  const links: [string, TranslationKey][] = [['/', 'home'], ['/search', 'search'], ['/education', 'education'], ['/jobs', 'jobs'], ['/news', 'news']];
  return <header className="topbar">
    <Link href="/" className="brand" aria-label="Ajju World home"><span className="brand-mark"><Compass size={21}/></span><span>ajju<span style={{ color: 'hsl(24 74% 52%)' }}>world</span></span></Link>
    <nav className="nav-links" aria-label={t('explore')}>{links.map(([href, key]) => <Link key={href} href={href}>{t(key)}</Link>)}</nav>
    <label className="sr-only" htmlFor="language">{t('language')}</label>
    <select id="language" className="language-select" value={locale} onChange={e => setLocale(e.target.value as typeof locale)} aria-label={t('language')} data-testid="select-language">
      {locales.map(code => <option value={code} key={code}>{languageNames[code]}</option>)}
    </select>
  </header>;
}
export function Footer() {
  const { t } = useI18n();
  return <footer className="footer"><span>Ajju World · {t('footerNote')}</span><nav aria-label={t('about')}><Link href="/about">{t('about')}</Link><Link href="/contact">{t('contact')}</Link><Link href="/privacy">{t('privacy')}</Link><Link href="/terms">{t('terms')}</Link></nav></footer>;
}
export function Shell({ children }: { children: ReactNode }) {
  return <div className="app-shell"><Header/><main className="page-wrap">{children}<Footer/></main></div>;
}
function ExternalLink({ item, description }: { item: Resource; description?: string }) {
  const { t } = useI18n();
  return <a className="resource-link" href={item.href} target="_blank" rel="noopener noreferrer" onClick={event => {
    const hasQuery = [...new URL(item.href).searchParams.values()].some(value => value.trim().length > 0);
    if (item.requiresQuery && !hasQuery) {
      event.preventDefault();
      window.alert(t('enterQuery'));
    }
  }} data-testid={`link-${item.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}>
    <span><strong>{item.name}</strong><small>{description ?? (item.description ? t(item.description) : t('sourceDescription'))}</small></span>
    <span className="external-tag">{t('external')} <ArrowUpRight size={14}/></span>
  </a>;
}
function PanelTitle({ icon: Icon, title, style = '' }: { icon: typeof Search; title: string; style?: string }) {
  return <div className="tool-title"><span className={`tool-icon ${style}`}><Icon size={19}/></span><h1>{title}</h1></div>;
}
function PageIntro({ icon: Icon, title, description }: { icon: typeof Search; title: string; description: string }) {
  return <div className="section-head"><span className="section-kicker"><Icon size={13}/>Ajju World</span><h2>{title}</h2><p>{description}</p></div>;
}
function ToolPanel({ children }: { children: ReactNode }) { return <section className="panel content-section">{children}</section>; }
function SearchField({ value, setValue, label, placeholder }: { value: string; setValue: (v: string) => void; label: string; placeholder: string }) {
  return <><label className="sr-only" htmlFor="query">{label}</label><input className="text-input" id="query" value={value} onChange={e => setValue(e.target.value)} placeholder={placeholder} /></>;
}

export function Home() {
  const { t, locale } = useI18n();
  const imageCopy = getAIImageCopy(locale);
  const [query, setQuery] = useState('');
  function submit(e: FormEvent<HTMLFormElement>) { searchForm(e, query, q => `https://duckduckgo.com/?q=${q}`, t('enterQuery')); }
  return <Shell>
    <section className="hero" aria-labelledby="hero-title"><div className="hero-content">
      <span className="eyebrow"><Sparkles size={14}/>{t('tagline')}</span><h1 id="hero-title">{t('heroTitle')}</h1><p>{t('heroDescription')}</p>
      <form className="search-form" role="search" onSubmit={submit}><Search size={19} aria-hidden="true"/><label className="sr-only" htmlFor="home-search">{t('searchPlaceholder')}</label><input id="home-search" type="search" value={query} onChange={e => setQuery(e.target.value)} placeholder={t('searchPlaceholder')}/><button className="button-primary" type="submit">{t('searchButton')}<ArrowRight size={16}/></button></form>
    </div><div className="hero-aside" aria-hidden="true"><Compass size={75} strokeWidth={1.1}/></div></section>
    <div className="quick-row"><span className="quick-label">{t('explore')}</span>{categories.slice(0, 6).map(c => <Link className="quick-link" href={c.href} key={c.href}>{t(c.title)}</Link>)}</div>
    <section className="content-section" aria-labelledby="tools-heading"><div className="section-head"><span className="section-kicker">{t('explore')}</span><h2 id="tools-heading">{t('explore')}</h2><p>{t('tagline')}</p></div>
      <div className="tools-grid">{categories.map(({ href, title, description, icon: Icon, style }) => <Link href={href} className={`tool-card ${style}`} key={href} data-testid={`card-${href.slice(1)}`}><span className="tool-icon"><Icon size={19}/></span><strong>{t(title)}</strong><span>{href === '/ai-image' ? imageCopy.homeDescription : t(description)}</span></Link>)}</div>
    </section>
  </Shell>;
}
export function SearchPage() {
  const { t } = useI18n(); const [query, setQuery] = useState('');
  function submit(e: FormEvent<HTMLFormElement>) { searchForm(e, query, q => `https://duckduckgo.com/?q=${q}`, t('enterQuery')); }
  return <Shell><PageIntro icon={Search} title={t('search')} description={t('searchDescription')}/><ToolPanel><PanelTitle icon={Search} title={t('search')}/><p className="tool-intro">{t('searchDescription')}</p><form className="form-row" role="search" onSubmit={submit}><SearchField value={query} setValue={setQuery} label={t('queryLabel')} placeholder={t('searchPlaceholder')}/><button className="button-primary" type="submit"><Search size={16}/>{t('openResults')}</button></form></ToolPanel></Shell>;
}
export function VideoPage() {
  const { t } = useI18n(); const [query, setQuery] = useState(''); const [file, setFile] = useState<File|null>(null);
  const url = useMemo(() => file ? URL.createObjectURL(file) : '', [file]);
  useEffect(() => () => { if (url) URL.revokeObjectURL(url); }, [url]);
  const youtube: Resource = { name: 'YouTube', href: `https://www.youtube.com/results?search_query=${encodeURIComponent(query.trim())}`, requiresQuery: true };
  const vimeo: Resource = { name: 'Vimeo', href: `https://vimeo.com/search?q=${encodeURIComponent(query.trim())}`, requiresQuery: true };
  return <Shell><PageIntro icon={Video} title={t('videoTitle')} description={t('videoDescription')}/><ToolPanel><div className="tool-layout"><div><PanelTitle icon={Video} title={t('video')}/><p className="tool-intro">{t('videoDescription')}</p><SearchField value={query} setValue={setQuery} label={t('queryLabel')} placeholder={t('queryPlaceholder')}/><div className="link-list" style={{ marginTop: 10 }}><ExternalLink item={youtube} description={t('youtubeSearch')}/><ExternalLink item={vimeo} description={t('vimeoSearch')}/></div><h3 className="subheading" style={{ marginTop: 22 }}>{t('videoPreview')}</h3><p className="hint">{t('previewDescription')}</p><label className="button-dark file-label"><Video size={16}/>{t('chooseVideo')}<input type="file" accept="video/*" aria-label={t('chooseVideo')} onChange={e => setFile(e.target.files?.[0] ?? null)}/></label></div><div className="video-stage">{url ? <video src={url} controls playsInline aria-label={file?.name}/> : <div className="video-empty"><Video size={29}/><strong>{t('noVideo')}</strong><span>{t('previewDescription')}</span></div>}</div></div></ToolPanel></Shell>;
}
export function ShoppingPage() {
  const { t } = useI18n(); const [query, setQuery] = useState('');
  const stores: Resource[] = [{name:'Amazon',href:'https://www.amazon.com/'},{name:'eBay',href:'https://www.ebay.com/'},{name:'Etsy',href:'https://www.etsy.com/'}];
  function submit(e: FormEvent<HTMLFormElement>) { searchForm(e, query, q => `https://www.google.com/search?tbm=shop&q=${q}`, t('enterQuery')); }
  return <Shell><PageIntro icon={ShoppingBag} title={t('shopping')} description={t('shoppingDescription')}/><ToolPanel><div className="tool-layout"><div><PanelTitle icon={ShoppingBag} title={t('shopping')}/><p className="tool-intro">{t('shoppingDescription')}</p><form className="form-row" onSubmit={submit}><SearchField value={query} setValue={setQuery} label={t('queryLabel')} placeholder={t('queryPlaceholder')}/><button className="button-primary"><Search size={16}/>{t('googleShopping')}</button></form></div><div><h2 className="subheading">{t('stores')}</h2><div className="link-list">{stores.map(item => <ExternalLink item={item} description={t('storeDescription')} key={item.name}/>)}</div></div></div></ToolPanel></Shell>;
}
const gradeSubjects: Record<string, string[]> = {
  '1': ['ગુજરાતી', 'ગણિત', 'પર્યાવરણ'], '2': ['ગુજરાતી', 'ગણિત', 'પર્યાવરણ'],
  '3': ['ગુજરાતી', 'ગણિત', 'પર્યાવરણ'], '4': ['ગુજરાતી', 'ગણિત', 'પર્યાવરણ'],
  '5': ['ગુજરાતી', 'ગણિત', 'પર્યાવરણ'], '6': ['ગુજરાતી', 'અંગ્રેજી', 'ગણિત', 'વિજ્ઞાન', 'સામાજિક વિજ્ઞાન'],
  '7': ['ગુજરાતી', 'અંગ્રેજી', 'ગણિત', 'વિજ્ઞાન', 'સામાજિક વિજ્ઞાન'],
  '8': ['ગુજરાતી', 'અંગ્રેજી', 'ગણિત', 'વિજ્ઞાન', 'સામાજિક વિજ્ઞાન'],
  '9': ['ગુજરાતી', 'અંગ્રેજી', 'ગણિત', 'વિજ્ઞાન', 'સામાજિક વિજ્ઞાન'],
  '10': ['ગુજરાતી', 'અંગ્રેજી', 'ગણિત', 'વિજ્ઞાન', 'સામાજિક વિજ્ઞાન'],
  '11': ['ગુજરાતી', 'અંગ્રેજી', 'અર્થશાસ્ત્ર', 'ઇતિહાસ', 'ભૂગોળ', 'રાજ્યશાસ્ત્ર'],
  '12': ['ગુજરાતી', 'અંગ્રેજી', 'અર્થશાસ્ત્ર', 'ઇતિહાસ', 'ભૂગોળ', 'રાજ્યશાસ્ત્ર'],
};
const gradeTenQuestions = [
  { subject: 'ગણિત', question: '12 × 8 નો જવાબ કેટલો?', options: ['86', '96', '108', '112'], answer: 1, explanation: '12 × 8 = 96.' },
  { subject: 'સામાજિક વિજ્ઞાન', question: 'ગુજરાતની રાજધાની કઈ છે?', options: ['સુરત', 'રાજકોટ', 'ગાંધીનગર', 'વડોદરા'], answer: 2, explanation: 'ગુજરાતની રાજધાની ગાંધીનગર છે.' },
  { subject: 'વિજ્ઞાન', question: 'પાણીનું રાસાયણિક સૂત્ર કયું છે?', options: ['CO₂', 'H₂O', 'O₂', 'NaCl'], answer: 1, explanation: 'પાણીનું રાસાયણિક સૂત્ર H₂O છે.' },
  { subject: 'ગુજરાતી', question: 'ભાષામાં શબ્દોનો સમૂહ જે સંપૂર્ણ અર્થ આપે તેને શું કહે છે?', options: ['અક્ષર', 'વાક્ય', 'માત્રા', 'ધ્વનિ'], answer: 1, explanation: 'સંપૂર્ણ અર્થ આપતા શબ્દસમૂહને વાક્ય કહે છે.' },
];
export function EducationPage() {
  const { t } = useI18n();
  const [grade, setGrade] = useState('10');
  const [subject, setSubject] = useState('ગણિત');
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [checked, setChecked] = useState(false);
  const subjects = gradeSubjects[grade] ?? gradeSubjects['10'];
  const questions = grade === '10' ? gradeTenQuestions.filter(q => subject === 'બધા વિષયો' || q.subject === subject) : [];
  const score = questions.filter((q, i) => answers[i] === q.answer).length;
  useEffect(() => { if (!subjects.includes(subject)) setSubject(subjects[0]); }, [grade]);
  return <Shell><PageIntro icon={GraduationCap} title={t('education')} description="ધોરણ 1થી 12 પસંદ કરો અને Ajju World પર જ અભ્યાસ કરો."/><ToolPanel>
    <PanelTitle icon={GraduationCap} title="Ajju World અભ્યાસ વિભાગ"/>
    <p className="tool-intro">ધોરણ અને વિષય પસંદ કરો. નોંધ: હાલ ધોરણ 10 માટે નમૂનાના MCQ ઉપલબ્ધ છે; અન્ય ધોરણોની સંપૂર્ણ પાઠવાર નોટ્સ ઉમેરવાની બાકી છે.</p>
    <div className="tool-layout">
      <div>
        <label htmlFor="study-grade" className="field-label">ધોરણ પસંદ કરો</label>
        <select id="study-grade" className="text-input" value={grade} onChange={e => { setGrade(e.target.value); setAnswers({}); setChecked(false); }}>
          {Array.from({length:12},(_,i)=><option value={String(i+1)} key={i}>ધોરણ {i+1}</option>)}
        </select>
        <label htmlFor="study-subject" className="field-label" style={{display:'block',marginTop:14}}>વિષય પસંદ કરો</label>
        <select id="study-subject" className="text-input" value={subject} onChange={e => {setSubject(e.target.value);setAnswers({});setChecked(false);}}>
          {subjects.map(s=><option value={s} key={s}>{s}</option>)}
          {grade === '10' && <option value="બધા વિષયો">બધા વિષયો</option>}
        </select>
        <div className="category-block" style={{marginTop:16}}>
          <h3><BookOpen size={17}/> અભ્યાસ નોટ્સ</h3>
          <p><strong>ધોરણ {grade} · {subject}</strong></p>
          {grade === '10' ? <><p>ધોરણ 10ના પસંદ કરેલા વિષય માટે અભ્યાસ સામગ્રી આ વિભાગમાં જ ગોઠવવામાં આવશે.</p><p className="hint">હાલ ઉપલબ્ધ નમૂનાના MCQથી શરૂઆત કરો. સંપૂર્ણ પાઠવાર નોટ્સ અને સ્વાધ્યાયના જવાબો ઉમેરવાના બાકી છે.</p></> : <><p>ધોરણ {grade} · {subject} માટેનો વિભાગ તૈયાર છે.</p><p className="hint">આ ધોરણ માટે પાઠવાર નોટ્સ, સ્વાધ્યાય અને MCQ પ્રશ્નબેંક હજી ઉમેરવાના બાકી છે.</p></>}
        </div>
      </div>
      <div>
        <h2 className="subheading">MCQ પ્રેક્ટિસ · ધોરણ {grade}</h2>
        {questions.length ? <>
          {questions.map((q,i)=><fieldset key={q.question} className="category-block" style={{marginBottom:14,border:0}}><legend><strong>{i+1}. {q.question}</strong></legend>{q.options.map((option,j)=><label key={option} style={{display:'block',padding:'7px 0',cursor:'pointer'}}><input type="radio" name={`question-${i}`} checked={answers[i]===j} onChange={()=>{setAnswers(a=>({...a,[i]:j}));setChecked(false);}}/> {option}</label>)}{checked&&<p className="hint">{answers[i]===q.answer?'સાચો જવાબ!':'સાચો જવાબ: '+q.options[q.answer]} — {q.explanation}</p>}</fieldset>)}
          <button type="button" className="button-primary" onClick={()=>setChecked(true)}>જવાબ તપાસો</button>
          {checked&&<div className="warning-box" style={{marginTop:12}}><strong>તમારો સ્કોર: {score}/{questions.length}</strong></div>}
          <button type="button" className="button-dark" style={{marginTop:10}} onClick={()=>{setAnswers({});setChecked(false);}}>ફરીથી ટેસ્ટ આપો</button>
        </> : <div className="warning-box"><strong>હાલ આ પસંદગી માટે પ્રશ્નો ઉપલબ્ધ નથી.</strong> પ્રશ્નબેંક ઉમેરાય પછી આ વિભાગમાં જ MCQ ટેસ્ટ આપી શકાશે. અભ્યાસ માટે બીજી વેબસાઇટ પર આપમેળે મોકલવામાં નહીં આવે.</div>}
      </div>
    </div>
  </ToolPanel></Shell>;
}
const india: Resource[] = [
  { name:'National Career Service',href:'https://www.ncs.gov.in/',description:'sourceDescription' },
  { name:'UPSC',href:'https://upsc.gov.in/',description:'sourceDescription' },
  { name:'Staff Selection Commission (SSC)',href:'https://ssc.gov.in/',description:'sourceDescription' },
];
export function JobsPage() {
  const { t } = useI18n(); const [query,setQuery]=useState('');
  const links: Resource[]=[{name:'Indeed',href:`https://www.indeed.com/jobs?q=${encodeURIComponent(query.trim())}`,description:'jobSearch',requiresQuery:true},{name:'LinkedIn Jobs',href:`https://www.linkedin.com/jobs/search/?keywords=${encodeURIComponent(query.trim())}`,description:'searchLinkedIn',requiresQuery:true}];
  return <Shell><PageIntro icon={BriefcaseBusiness} title={t('jobs')} description={t('jobsDescription')}/><ToolPanel><div className="tool-layout"><div><PanelTitle icon={BriefcaseBusiness} title={t('jobs')}/><p className="tool-intro">{t('jobsDescription')}</p><SearchField value={query} setValue={setQuery} label={t('roleLabel')} placeholder={t('rolePlaceholder')}/><div className="link-list" style={{ marginTop:10 }}>{links.map(item=><ExternalLink item={item} key={item.name}/>)}</div></div><div><h2 className="subheading">{t('officialIndia')}</h2><div className="link-list">{india.map(item=><ExternalLink item={item} key={item.name}/>)}</div></div></div></ToolPanel></Shell>;
}
export function EarningPage() {
  const { t }=useI18n();
  const refs: Resource[]=[{name:'Upwork',href:'https://www.upwork.com/'},{name:'Fiverr',href:'https://www.fiverr.com/'},{name:'Amazon Associates',href:'https://affiliate-program.amazon.in/'},{name:'YouTube Creator Academy',href:'https://www.youtube.com/creators/'},{name:'UserTesting',href:'https://www.usertesting.com/get-paid-to-test'}];
  const groups: [TranslationKey,TranslationKey][]=[['freelance','freelanceCopy'],['affiliate','affiliateCopy'],['content','contentCopy']];
  return <Shell><PageIntro icon={WalletCards} title={t('earning')} description={t('earningDescription')}/><ToolPanel><PanelTitle icon={WalletCards} title={t('earning')}/><p className="tool-intro">{t('earningDescription')}</p><div className="tool-layout"><div className="category-list">{groups.map(([title,copy])=><article className="category-block" key={title}><h3>{t(title)}</h3><p>{t(copy)}</p></article>)}<div className="warning-box"><strong><ShieldAlert size={17}/>{t('scamTitle')}</strong>{t('scamCopy')}</div></div><div className="link-list">{refs.map(item=><ExternalLink item={item} key={item.name}/>)}</div></div></ToolPanel></Shell>;
}
const news: Resource[]=[{name:'Reuters',href:'https://www.reuters.com/'},{name:'Associated Press (AP)',href:'https://apnews.com/'},{name:'BBC News',href:'https://www.bbc.com/news'},{name:'The Hindu',href:'https://www.thehindu.com/'}];
export function NewsPage() { const {t}=useI18n(); return <Shell><PageIntro icon={Newspaper} title={t('news')} description={t('newsDescription')}/><ToolPanel><PanelTitle icon={Newspaper} title={t('newsSources')}/><p className="tool-intro">{t('newsDescription')}</p><div className="link-list">{news.map(item=><ExternalLink item={item} key={item.name}/>)}</div></ToolPanel></Shell>; }
function ConfigPage({ imageMode=false }: { imageMode?: boolean }) {
  const { t }=useI18n(); const title=imageMode?t('aiImage'):t('assistant'), text=imageMode?t('aiImageDescription'):t('assistantDescription');
  return <Shell><PageIntro icon={imageMode?Image:Sparkles} title={title} description={text}/><ToolPanel><PanelTitle icon={imageMode?Image:Sparkles} title={title}/><p className="tool-intro">{text}</p><div className="warning-box"><strong>{t('notConfigured')}</strong>{t('unavailable')}</div></ToolPanel></Shell>;
}
export function AIImagePage() {
  const { t, locale } = useI18n();
  const copy = getAIImageCopy(locale);
  const [providerConfigured, setProviderConfigured] = useState<boolean | null>(null);
  const [statusFailed, setStatusFailed] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState('');
  const apiBase = `${import.meta.env.BASE_URL.replace(/\/$/, '')}/api/ai-image`;

  async function checkProvider() {
    setStatusFailed(false);
    try {
      const response = await fetch(`${apiBase}/status`, { cache: 'no-store' });
      if (!response.ok) throw new Error('Could not check provider status.');
      const result: unknown = await response.json();
      if (typeof result !== 'object' || result === null || !('configured' in result) || typeof result.configured !== 'boolean') {
        throw new Error('Invalid provider status response.');
      }
      setProviderConfigured(result.configured);
    } catch {
      setProviderConfigured(null);
      setStatusFailed(true);
    }
  }

  useEffect(() => {
    void checkProvider();
  }, [apiBase]);

  useEffect(() => () => {
    if (imageUrl) URL.revokeObjectURL(imageUrl);
  }, [imageUrl]);

  async function generateImage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const cleanPrompt = prompt.trim();
    if (!cleanPrompt || !enabled || providerConfigured !== true) return;
    setError('');
    setIsGenerating(true);
    setImageUrl('');
    try {
      const response = await fetch(`${apiBase}/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: cleanPrompt }),
      });
      if (!response.ok) {
        const body: unknown = await response.json().catch(() => null);
        const detail = typeof body === 'object' && body !== null && 'error' in body && typeof body.error === 'string'
          ? body.error
          : copy.generationError;
        throw new Error(detail);
      }
      const contentType = response.headers.get('content-type') ?? '';
      if (!contentType.startsWith('image/')) throw new Error(copy.generationError);
      const image = await response.blob();
      if (image.size === 0) throw new Error(copy.generationError);
      setImageUrl(URL.createObjectURL(image));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : copy.generationError);
    } finally {
      setIsGenerating(false);
    }
  }

  return <Shell>
    <PageIntro icon={Image} title={t('aiImage')} description={copy.intro}/>
    <ToolPanel>
      <PanelTitle icon={Image} title={t('aiImage')}/>
      <p className="tool-intro">{copy.intro}</p>
      {providerConfigured === null && !statusFailed && <p className="hint" role="status">{copy.checking}</p>}
      {providerConfigured === false && <div className="warning-box" role="status"><strong>{t('notConfigured')}</strong>{copy.notConfiguredDetail}<small className="image-setup-hint">{copy.setupHint}</small></div>}
      {statusFailed && <div className="warning-box" role="alert"><strong>{copy.statusError}</strong><button type="button" className="button-dark image-retry" onClick={() => void checkProvider()}>{copy.retry}</button></div>}
      {providerConfigured === true && <>
        <div className="image-provider-consent">
          <label className="image-consent-label">
            <input type="checkbox" checked={enabled} onChange={event => { setEnabled(event.target.checked); setError(''); }}/>
            <span>{copy.consent}</span>
          </label>
          <p className="hint">{copy.providerNotice}</p>
        </div>
        <form className="image-generator-form" onSubmit={generateImage}>
          <label htmlFor="image-prompt">{copy.promptLabel}</label>
          <textarea id="image-prompt" className="text-input image-prompt" value={prompt} onChange={event => setPrompt(event.target.value)} maxLength={1200} placeholder={t('queryPlaceholder')} disabled={!enabled || isGenerating}/>
          <div className="image-form-footer">
            <span className="hint">{prompt.trim().length}/1200</span>
            <button className="button-primary" type="submit" disabled={!enabled || !prompt.trim() || isGenerating}>
              {isGenerating ? copy.generating : copy.generate}
            </button>
          </div>
        </form>
        {error && <div className="warning-box image-error" role="alert"><strong>{copy.generationError}</strong>{error !== copy.generationError && <span>{error}</span>}</div>}
        {imageUrl && <div className="image-result">
          <img src={imageUrl} alt={prompt.trim()} />
          <a className="button-dark image-download" href={imageUrl} download="ajju-world-generated-image.png"><Download size={16}/>{copy.download}</a>
        </div>}
      </>}
    </ToolPanel>
  </Shell>;
}
export function AssistantPage() { return <ConfigPage/>; }
type StaticKind='about'|'contact'|'privacy'|'terms';
export function StaticPage({ kind }: { kind: StaticKind }) {
  const {t, locale}=useI18n();
  const imageCopy=getAIImageCopy(locale);
  const config: Record<StaticKind,{title:TranslationKey;description:TranslationKey;sections:[TranslationKey,TranslationKey][]}>={
    about:{title:'about',description:'aboutDescription',sections:[['aboutScope','aboutScopeCopy'],['aboutLimit','aboutLimitCopy']]},
    contact:{title:'contact',description:'contactDescription',sections:[]},
    privacy:{title:'privacy',description:'privacyDescription',sections:[['privacyStorage','privacyStorageCopy']]},
    terms:{title:'terms',description:'termsDescription',sections:[['termsAccuracy','termsAccuracyCopy'],['termsUse','termsUseCopy']]},
  };
  const page=config[kind];
  return <Shell><PageIntro icon={BookOpen} title={t(page.title)} description={t(page.description)}/><ToolPanel><div className="legal-copy"><PanelTitle icon={BookOpen} title={t(page.title)}/><p>{t(page.description)}</p>{page.sections.map(([heading,body])=><section key={heading}><h2>{t(heading)}</h2><p>{body==='aboutLimitCopy'?imageCopy.aboutLimit:t(body)}</p></section>)}</div></ToolPanel></Shell>;
}
export function NotFound() { const {t}=useI18n(); return <Shell><section className="panel"><h1>{t('pageNotFound')}</h1><Link href="/" className="button-primary">{t('returnHome')}<ArrowRight size={16}/></Link></section></Shell>; }

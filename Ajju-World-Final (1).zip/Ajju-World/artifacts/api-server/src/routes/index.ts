import { Router, type IRouter } from "express";
import healthRouter from "./health";
import aiImageRouter from "./ai-image";

const router: IRouter = Router();

router.use(healthRouter);
router.use(aiImageRouter);

export default router;

import { Router, type IRouter } from "express";

const router: IRouter = Router();
const providerUrl = "https://gen.pollinations.ai/image/";
const providerModel = "black-forest-labs/flux.1-schnell";
const maxPromptLength = 1200;
const maxImageBytes = 12 * 1024 * 1024;

function getProviderKey() {
  return process.env["POLLINATIONS_API_KEY"]?.trim();
}

router.get("/ai-image/status", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ configured: Boolean(getProviderKey()) });
});

router.post("/ai-image/generate", async (req, res) => {
  const apiKey = getProviderKey();
  if (!apiKey) {
    res.status(503).json({ error: "Image generation is not configured." });
    return;
  }

  const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
  if (!prompt || prompt.length > maxPromptLength) {
    res.status(400).json({
      error: `Enter a prompt of 1–${maxPromptLength} characters.`,
    });
    return;
  }

  const imageUrl = new URL(encodeURIComponent(prompt), providerUrl);
  imageUrl.searchParams.set("model", providerModel);

  try {
    const providerResponse = await fetch(imageUrl, {
      headers: {
        Accept: "image/*",
        Authorization: `Bearer ${apiKey}`,
      },
      signal: AbortSignal.timeout(90_000),
    });

    if (!providerResponse.ok) {
      const message =
        providerResponse.status === 401 || providerResponse.status === 403
          ? "The image provider rejected its configured credentials."
          : providerResponse.status === 429
            ? "The image provider limit was reached. Try again later."
            : `The image provider returned an error (${providerResponse.status}).`;
      res.status(502).json({ error: message });
      return;
    }

    const contentType = providerResponse.headers
      .get("content-type")
      ?.split(";")[0]
      .trim();
    if (!contentType?.startsWith("image/")) {
      res.status(502).json({ error: "The provider did not return an image." });
      return;
    }

    const declaredSize = Number(providerResponse.headers.get("content-length"));
    if (Number.isFinite(declaredSize) && declaredSize > maxImageBytes) {
      res.status(502).json({ error: "The generated image is larger than allowed." });
      return;
    }

    const image = Buffer.from(await providerResponse.arrayBuffer());
    if (image.length === 0 || image.length > maxImageBytes) {
      res.status(502).json({ error: "The provider returned an invalid image." });
      return;
    }

    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Type", contentType);
    res.status(200).send(image);
  } catch (error) {
    const message =
      error instanceof Error && error.name === "TimeoutError"
        ? "The image provider took too long to respond. Try again later."
        : "The image provider could not complete the request. Check its status and try again.";
    res.status(502).json({ error: message });
  }
});

export default router;
